function m = knnRegress(x,y,k)

    m.x = x;
    m.y = y;
    m.k = k;
    m.model = 'KNN';


% your code here
    
end